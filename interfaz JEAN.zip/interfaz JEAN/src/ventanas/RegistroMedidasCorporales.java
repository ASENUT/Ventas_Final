package ventanas;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import javax.swing.JOptionPane;

public class RegistroMedidasCorporales extends javax.swing.JFrame {

    String fechatrata = "";
    String codptrata = "";
    HistorialNutricional hn = new HistorialNutricional();
    String nomtrata = hn.nomtrata;
    MetodoComunes metodoscomunes = new MetodoComunes();

    public RegistroMedidasCorporales() {
        initComponents();
        this.setLocationRelativeTo(null);

        metodoscomunes.SoloNumeros(txtBusto);
        metodoscomunes.SoloNumeros(txtEstomago);
        metodoscomunes.SoloNumeros(txtAbdomen);
        metodoscomunes.SoloNumeros(txtMedidaCadera);
        metodoscomunes.SoloNumeros(txtMedidaCintura);
        metodoscomunes.SoloNumeros(txtMusloDER);
        metodoscomunes.SoloNumeros(txtBrazoIZQ);
        metodoscomunes.SoloNumeros(txtEntrepiernaDER);
        metodoscomunes.SoloNumeros(txtEntrepiernaIZQ);
        metodoscomunes.SoloNumeros(txtBrazoDER);
        metodoscomunes.SoloNumeros(txtBrazoIZQ);
    }

    public void vaciar() {
        txtAbdomen.setText("");
        txtBrazoDER.setText("");
        txtBrazoIZQ.setText("");
        txtBusto.setText("");
        txtEntrepiernaDER.setText("");
        txtEntrepiernaIZQ.setText("");
        txtEstomago.setText("");
        txtMedidaCadera.setText("");
        txtMedidaCintura.setText("");
        txtMusloDER.setText("");
        txtMusloIZQ.setText("");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel46 = new javax.swing.JLabel();
        txtBusto = new javax.swing.JTextField();
        jLabel83 = new javax.swing.JLabel();
        txtEstomago = new javax.swing.JTextField();
        jLabel84 = new javax.swing.JLabel();
        txtMedidaCintura = new javax.swing.JTextField();
        jLabel85 = new javax.swing.JLabel();
        txtAbdomen = new javax.swing.JTextField();
        jLabel86 = new javax.swing.JLabel();
        txtMedidaCadera = new javax.swing.JTextField();
        jLabel87 = new javax.swing.JLabel();
        txtMusloIZQ = new javax.swing.JTextField();
        jLabel88 = new javax.swing.JLabel();
        txtEntrepiernaIZQ = new javax.swing.JTextField();
        jLabel89 = new javax.swing.JLabel();
        txtBrazoIZQ = new javax.swing.JTextField();
        jLabel92 = new javax.swing.JLabel();
        txtBrazoDER = new javax.swing.JTextField();
        txtEntrepiernaDER = new javax.swing.JTextField();
        jLabel91 = new javax.swing.JLabel();
        txtMusloDER = new javax.swing.JTextField();
        jLabel90 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        txtFechaMedida = new com.toedter.calendar.JDateChooser();
        jLabel51 = new javax.swing.JLabel();
        txtCedula = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        btnGuardar = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();

        setUndecorated(true);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel46.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel46.setText("Busto");
        getContentPane().add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, -1, -1));
        getContentPane().add(txtBusto, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 70, 120, 30));

        jLabel83.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel83.setText("Estómago:");
        getContentPane().add(jLabel83, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 80, -1, -1));
        getContentPane().add(txtEstomago, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 70, 100, 30));

        jLabel84.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel84.setText("Cintura:");
        getContentPane().add(jLabel84, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, -1, -1));
        getContentPane().add(txtMedidaCintura, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 120, 120, 30));

        jLabel85.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel85.setText("Abdomen:");
        getContentPane().add(jLabel85, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 130, -1, -1));
        getContentPane().add(txtAbdomen, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 120, 100, 30));

        jLabel86.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel86.setText("Caderas:");
        getContentPane().add(jLabel86, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, -1, -1));
        getContentPane().add(txtMedidaCadera, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 170, 120, 30));

        jLabel87.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel87.setText("Muslo IZQ:");
        getContentPane().add(jLabel87, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, -1, -1));
        getContentPane().add(txtMusloIZQ, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 220, 120, 30));

        jLabel88.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel88.setText("Entrepierna IZQ:");
        getContentPane().add(jLabel88, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 280, -1, -1));
        getContentPane().add(txtEntrepiernaIZQ, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 270, 120, 30));

        jLabel89.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel89.setText("Brazo IZQ:");
        getContentPane().add(jLabel89, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 330, -1, -1));
        getContentPane().add(txtBrazoIZQ, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 320, 120, 30));

        jLabel92.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel92.setText("Brazo DER:");
        getContentPane().add(jLabel92, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 330, -1, -1));
        getContentPane().add(txtBrazoDER, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 320, 100, 30));
        getContentPane().add(txtEntrepiernaDER, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 270, 100, 30));

        jLabel91.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel91.setText("Entrepierna DER:");
        getContentPane().add(jLabel91, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 280, -1, -1));
        getContentPane().add(txtMusloDER, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 220, 100, 30));

        jLabel90.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel90.setText("Muslo DER:");
        getContentPane().add(jLabel90, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 230, -1, -1));

        jLabel47.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel47.setText("Fecha:");
        getContentPane().add(jLabel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 10, 40, 30));

        txtFechaMedida.setDateFormatString("yyyy-MM-dd");
        getContentPane().add(txtFechaMedida, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 10, 130, 30));

        jLabel51.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel51.setText("Cedula:");
        getContentPane().add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        txtCedula.setEditable(false);
        getContentPane().add(txtCedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 10, 170, 30));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel1.setText("cm");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 70, 20, 30));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel2.setText("cm");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 120, 20, 30));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel3.setText("cm");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 120, 20, 30));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel4.setText("cm");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 170, 20, 30));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel5.setText("cm");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 220, 20, 30));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel6.setText("cm");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 220, 20, 30));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel7.setText("cm");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 270, 20, 30));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel8.setText("cm");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 270, 20, 30));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel9.setText("cm");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 320, 20, 30));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel10.setText("cm");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 320, 20, 30));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel11.setText("cm");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 70, 20, 30));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel12.setText("2017-01-25");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 40, -1, -1));

        jLabel52.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel52.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        jLabel52.setPreferredSize(new java.awt.Dimension(650, 427));
        getContentPane().add(jLabel52, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 580, 430));

        jMenuBar1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        btnGuardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Save.png"))); // NOI18N
        btnGuardar.setText("Guardar");
        btnGuardar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnGuardarMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnGuardar);

        jMenu2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Back.png"))); // NOI18N
        jMenu2.setText("Regresar");
        jMenu2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu2MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void btnGuardarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnGuardarMouseClicked
        //Guardar
        txtCedula.setText(HistorialNutricional.cedulacorporal);
        PreparedStatement cmd;
        ResultSet rs;
        Conexion.Conectar();

        //////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////MEDIDAS CORPORALES/////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////
        String busto = txtBusto.getText();
        String estomago = txtEstomago.getText();
        String mcintura = txtMedidaCintura.getText();
        String abdomen = txtAbdomen.getText();
        String mcaderas = txtMedidaCadera.getText();
        String musloizq = txtMusloIZQ.getText();
        String musloder = txtMusloDER.getText();
        String entrepiernaizq = txtEntrepiernaIZQ.getText();
        String entrepiernader = txtEntrepiernaDER.getText();
        String brazoizq = txtBrazoIZQ.getText();
        String brazoder = txtBrazoDER.getText();
        String cedula = txtCedula.getText();

        System.out.println(fechatrata);
        String fdia = "";
        String fmes = "";
        if (txtFechaMedida.getCalendar().get(Calendar.DAY_OF_MONTH) <= 9) {
            fdia = "0" + txtFechaMedida.getCalendar().get(Calendar.DAY_OF_MONTH);
        } else {
            fdia = String.valueOf(txtFechaMedida.getCalendar().get(Calendar.DAY_OF_MONTH));
        }
        if ((txtFechaMedida.getCalendar().get(Calendar.MONTH) + 1) <= 9) {
            fmes = "0" + ((txtFechaMedida.getCalendar().get(Calendar.MONTH) + 1));
        } else {
            fmes = String.valueOf((txtFechaMedida.getCalendar().get(Calendar.MONTH) + 1));
        }

        String fechamedi = "'" + txtFechaMedida.getCalendar().get(Calendar.YEAR) + "-" + fmes + "-" + fdia + "'";

        try {
            cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO MEDIDAS_CORPORALES "
                    + "(FECHA_MEDICION, FECHA_TRATA, CEDULA, COD_TRATAMIENTO, BUSTO, ESTOMAGO, CINTURA, ABDOMEN, "
                    + "CADERAS, MUSLO_IZ, MUSLO_DER, ENTREPIERNA_IZ, ENTREPIERNA_DER, BRAZO_IZ, BRAZO_DER) "
                    + "VALUES (" + fechamedi + " , " + fechatrata + ", '" + cedula + "', '" + codptrata + "', '" + busto
                    + "', '" + estomago + "', '" + mcintura + "', '" + abdomen + "', '" + mcaderas + "', '" + musloizq
                    + "', '" + musloder + "', '" + entrepiernaizq + "', '" + entrepiernader + "', '" + brazoizq + "', '" + brazoder + "')");
            cmd.execute();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + "\nNo se ingreso Medidas Corporales");
        }
        System.out.println(fechamedi + " , " + fechatrata + ", '" + cedula + "', '" + codptrata + "', '" + busto
                + "', '" + estomago + "', '" + mcintura + "', '" + abdomen + "', '" + mcaderas + "', '" + musloizq
                + "', '" + musloder + "', '" + entrepiernaizq + "', '" + entrepiernader + "', '" + brazoizq + "', '" + brazoder);
        vaciar();
        //INSERT INTO PACIENTE_TRATAMIENTO (FECHA_TRATA, CEDULA, COD_TRATAMIENTO, CED_EMPLEADO) VALUES ('2016-12-12', '0802502948', '1', '1020304050');
    }//GEN-LAST:event_btnGuardarMouseClicked

    private void jMenu2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu2MouseClicked
        // TODO add your handling code here:
        TratamientoNutricional dg = new TratamientoNutricional();
        dg.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jMenu2MouseClicked

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        // TODO add your handling code here:
        ResultSet rs;
        HistorialNutricional rc = new HistorialNutricional();
        txtCedula.setText(rc.cedulacorporal);

        fechatrata = hn.fecha;
        txtCedula.setText(HistorialNutricional.cedulacorporal);

        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_TRATAMIENTO FROM TIPO_TRATAMIENTO WHERE NOM_TRATA = " + nomtrata);
            while (rs.next()) {
                codptrata = rs.getString(1);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se encotró el tratamiento");
        }

        System.out.println("cedula: " + txtCedula.getText());
        System.out.println("codigo tratamiento: " + codptrata);
        System.out.println("nombre tratamiento: " + nomtrata);
        System.out.println("Fecha trata: " + fechatrata);


    }//GEN-LAST:event_formWindowActivated

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegistroMedidasCorporales.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegistroMedidasCorporales.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegistroMedidasCorporales.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegistroMedidasCorporales.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistroMedidasCorporales().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu btnGuardar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel92;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JTextField txtAbdomen;
    private javax.swing.JTextField txtBrazoDER;
    private javax.swing.JTextField txtBrazoIZQ;
    private javax.swing.JTextField txtBusto;
    private javax.swing.JTextField txtCedula;
    private javax.swing.JTextField txtEntrepiernaDER;
    private javax.swing.JTextField txtEntrepiernaIZQ;
    private javax.swing.JTextField txtEstomago;
    private com.toedter.calendar.JDateChooser txtFechaMedida;
    private javax.swing.JTextField txtMedidaCadera;
    private javax.swing.JTextField txtMedidaCintura;
    private javax.swing.JTextField txtMusloDER;
    private javax.swing.JTextField txtMusloIZQ;
    // End of variables declaration//GEN-END:variables
}
