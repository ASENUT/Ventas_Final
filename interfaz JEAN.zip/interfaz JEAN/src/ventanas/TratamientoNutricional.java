package ventanas;

import java.awt.HeadlessException;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class TratamientoNutricional extends javax.swing.JFrame {

    static String cedulaFichaTN = "";

    public TratamientoNutricional() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        txtBusqueda = new javax.swing.JTextField();
        btnMEdidasCorporales = new javax.swing.JButton();
        btnPeso = new javax.swing.JButton();
        btnAntesDesp = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        btnHistorialNutricional = new javax.swing.JMenu();
        btnFichaEconomica = new javax.swing.JMenu();
        btnRegresar = new javax.swing.JMenu();

        jTextField1.setText("jTextField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setName("TratamientoCosmotologico"); // NOI18N
        setUndecorated(true);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Cedula", "Cita", "Tratamiento"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 160, 500, 90));

        txtBusqueda.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtBusquedaKeyPressed(evt);
            }
        });
        getContentPane().add(txtBusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 70, 320, 30));

        btnMEdidasCorporales.setText("Medidas Corporales");
        btnMEdidasCorporales.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnMEdidasCorporalesMouseClicked(evt);
            }
        });
        getContentPane().add(btnMEdidasCorporales, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 270, -1, -1));

        btnPeso.setText("Peso");
        btnPeso.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnPesoMouseClicked(evt);
            }
        });
        getContentPane().add(btnPeso, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 270, -1, -1));

        btnAntesDesp.setText("Foto Corporal");
        btnAntesDesp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnAntesDespMouseClicked(evt);
            }
        });
        getContentPane().add(btnAntesDesp, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 270, -1, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel2.setText("Nombre, Apellido o Cedula");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, 160, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 560, 320));

        jMenuBar1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        btnHistorialNutricional.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Report_1.png"))); // NOI18N
        btnHistorialNutricional.setText("Historial Nutricional");
        btnHistorialNutricional.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnHistorialNutricionalMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnHistorialNutricional);

        btnFichaEconomica.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Economic.png"))); // NOI18N
        btnFichaEconomica.setText("Ficha Economica");
        btnFichaEconomica.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnFichaEconomicaMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnFichaEconomica);

        btnRegresar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Back.png"))); // NOI18N
        btnRegresar.setText("Regresar");
        btnRegresar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnRegresarMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnRegresar);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRegresarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRegresarMouseClicked
        // TODO add your handling code here:
        cedulaFichaTN = "";
        if (Interfaz.tipousu.equalsIgnoreCase("Administrador")) {
            MenuAdministrativo to = new MenuAdministrativo();
            to.setVisible(true);
            this.setVisible(false);
        } else if (Interfaz.tipousu.equalsIgnoreCase("Empleado")) {
            MenuEmpleado to = new MenuEmpleado();
            to.setVisible(true);
            this.setVisible(false);
        }
    }//GEN-LAST:event_btnRegresarMouseClicked

    private void btnHistorialNutricionalMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnHistorialNutricionalMouseClicked
        // TODO add your handling code here:
        HistorialNutricional obj = new HistorialNutricional();
        obj.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnHistorialNutricionalMouseClicked

    private void btnFichaEconomicaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnFichaEconomicaMouseClicked
        // TODO add your handling code here:
        FichaNutricional obj = new FichaNutricional();
        obj.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnFichaEconomicaMouseClicked

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        // CARGAMOS TABLA
        DefaultTableModel dtm = new DefaultTableModel();
        ResultSet rs;
        String ced = "";

        ced = HistorialNutricional.cedulantri;
        if (ced.isEmpty()) {
            if (!TratamientoNutricional.cedulaFichaTN.isEmpty()) {
                txtBusqueda.setText(TratamientoNutricional.cedulaFichaTN);
            }
        } else {
            txtBusqueda.setText(ced);
        }

        try {
            //dtm.addColumn("Cédula");
            dtm.addColumn("Apellido");
            dtm.addColumn("Nombre");
            dtm.addColumn("Tratamiento");
            dtm.addColumn("Atendido por:");
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT P.APE_PAC, P.NOM_PAC, TT.NOM_TRATA, U.NOM_USUARIO FROM PACIENTE P, PACIENTE_TRATAMIENTO PT, TIPO_TRATAMIENTO TT, USUARIO U  WHERE P.CEDULA = PT.CEDULA AND PT.COD_TRATAMIENTO = TT.COD_TRATAMIENTO AND TT.COD_TRATA_FACIAL = 1 AND PT.CED_EMPLEADO = U.CED_EMPLEADO");
            while (rs.next()) {
                dtm.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)});
            }
            jTable1.setModel(dtm);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_formWindowOpened

    private void btnMEdidasCorporalesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnMEdidasCorporalesMouseClicked
        // TODO add your handling code here:
        MedidasCorporales to = new MedidasCorporales();
        to.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnMEdidasCorporalesMouseClicked

    private void btnPesoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnPesoMouseClicked
        // TODO add your handling code here:
        RegistroPeso to = new RegistroPeso();
        to.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnPesoMouseClicked

    private void btnAntesDespMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAntesDespMouseClicked
        // TODO add your handling code here:
        FotoCorporal to = new FotoCorporal();
        to.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnAntesDespMouseClicked

    private void txtBusquedaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBusquedaKeyPressed
        search();
    }//GEN-LAST:event_txtBusquedaKeyPressed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        int filaseleccionada;
        ResultSet rs;
        String nombre = "";
        String apellido = "";
        String trata = "";

        try {
            filaseleccionada = jTable1.getSelectedRow();
            if (filaseleccionada == -1) {
                JOptionPane.showMessageDialog(null, "No se ha seleccionado ninguna fila");
            } else {
                DefaultTableModel modelo_tabla = (DefaultTableModel) jTable1.getModel();
                nombre = "'" + (String) (modelo_tabla.getValueAt(filaseleccionada, 1)) + "'";
                apellido = "'" + (String) (modelo_tabla.getValueAt(filaseleccionada, 0)) + "'";
                trata = "'" + (String) (modelo_tabla.getValueAt(filaseleccionada, 2)) + "'";
                System.out.println(nombre + " " + apellido + " | " + trata);
            }
        } catch (HeadlessException ex) {
            JOptionPane.showMessageDialog(null, "Error: " + ex + "\nInténtelo nuevamente", " .::Error En la Operacion::.", JOptionPane.ERROR_MESSAGE);
        }

        try {
            String query = "SELECT PT.CEDULA"
                    + "	FROM PACIENTE_TRATAMIENTO PT,"
                    + " PACIENTE P, TIPO_TRATAMIENTO TT"
                    + " WHERE P.CEDULA = PT.CEDULA"
                    + " AND P.NOM_PAC = " + nombre
                    + " AND P.APE_PAC = " + apellido
                    + " AND TT.NOM_TRATA = " + trata
                    + " AND PT.CEDULA LIKE '" + txtBusqueda.getText() + "%'";

            rs = ventanas.Conexion.link.createStatement().executeQuery(query);
            //rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT P.APE_PAC, P.NOM_PAC, TT.NOM_TRATA, U.NOM_USUARIO FROM PACIENTE P, PACIENTE_TRATAMIENTO PT, TIPO_TRATAMIENTO TT, USUARIO U  WHERE P.CEDULA = PT.CEDULA AND PT.COD_TRATAMIENTO = TT.COD_TRATAMIENTO AND TT.COD_TRATA_FACIAL = 1 AND PT.CED_EMPLEADO = U.CED_EMPLEADO AND PT.CEDULA = '" + txtBusqueda.getText() + "'");
            while (rs.next()) {
                cedulaFichaTN = rs.getString(1);
            }
        } catch (SQLException e) {

        }
        System.out.println(cedulaFichaTN);
    }//GEN-LAST:event_jTable1MouseClicked

    void search() {
        DefaultTableModel dtm = new DefaultTableModel();
        ResultSet rs;
        try {
            //dtm.addColumn("Cédula");
            dtm.addColumn("Apellido");
            dtm.addColumn("Nombre");
            dtm.addColumn("Tratamiento");
            dtm.addColumn("Atendido por:");
            //rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT P.CEDULA, P.APE_PAC, P.NOM_PAC, TT.NOM_TRATA, U.NOM_USUARIO FROM PACIENTE P, PACIENTE_TRATAMIENTO PT, TIPO_TRATAMIENTO TT, USUARIO U  WHERE P.CEDULA = PT.CEDULA AND PT.COD_TRATAMIENTO = TT.COD_TRATAMIENTO AND TT.COD_TRATA_FACIAL = 1 AND PT.CED_EMPLEADO = U.CED_EMPLEADO");
            String query = "SELECT P.APE_PAC, "
                    + "P.NOM_PAC, "
                    + "TT.NOM_TRATA, "
                    + "U.NOM_USUARIO "
                    + "FROM PACIENTE P, "
                    + "PACIENTE_TRATAMIENTO PT, "
                    + "TIPO_TRATAMIENTO TT, "
                    + "USUARIO U  "
                    + "WHERE P.CEDULA = PT.CEDULA "
                    + "AND PT.COD_TRATAMIENTO = TT.COD_TRATAMIENTO "
                    + "AND TT.COD_TRATA_FACIAL = 1 "
                    + "AND PT.CED_EMPLEADO = U.CED_EMPLEADO "
                    + "AND (PT.CEDULA LIKE '" + txtBusqueda.getText() + "%'"
                    + "OR   P.APE_PAC LIKE '" + txtBusqueda.getText() + "%'"
                    + "OR   P.NOM_PAC LIKE '" + txtBusqueda.getText() + "%' )";

            rs = ventanas.Conexion.link.createStatement().executeQuery(query);
            //rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT P.APE_PAC, P.NOM_PAC, TT.NOM_TRATA, U.NOM_USUARIO FROM PACIENTE P, PACIENTE_TRATAMIENTO PT, TIPO_TRATAMIENTO TT, USUARIO U  WHERE P.CEDULA = PT.CEDULA AND PT.COD_TRATAMIENTO = TT.COD_TRATAMIENTO AND TT.COD_TRATA_FACIAL = 1 AND PT.CED_EMPLEADO = U.CED_EMPLEADO AND PT.CEDULA = '" + txtBusqueda.getText() + "'");
            while (rs.next()) {
                dtm.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)});
            }
            jTable1.setModel(dtm);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TratamientoNutricional.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TratamientoNutricional.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TratamientoNutricional.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TratamientoNutricional.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TratamientoNutricional().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAntesDesp;
    private javax.swing.JMenu btnFichaEconomica;
    private javax.swing.JMenu btnHistorialNutricional;
    private javax.swing.JButton btnMEdidasCorporales;
    private javax.swing.JButton btnPeso;
    private javax.swing.JMenu btnRegresar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField txtBusqueda;
    // End of variables declaration//GEN-END:variables
}
